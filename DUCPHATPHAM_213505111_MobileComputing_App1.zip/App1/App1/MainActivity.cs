﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.Collections.Generic;

namespace App1
{
    [Activity(Label = "App1", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private List<string> mItems;
        private ListView mListView;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            
            SetContentView(Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.OpenMenuPage);
            mListView = FindViewById<ListView>(Resource.Id.myListView);

            mItems = new List<string>();
            mItems.Add("Book 1");
            mItems.Add("Book 2");
            mItems.Add("Book 3");

            ArrayAdapter<string> adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1, mItems);

            mListView.Adapter = adapter;
            button.Click += delegate
            {
                StartActivity(typeof(MenuActivity));
            };

        }
    }
}

