using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App1
{
    [Activity(Label = "MenuActivity")]
    public class MenuActivity : Activity
    {
  
        protected override void OnCreate(Bundle savedInstanceState)
        {
            Button button = FindViewById<Button>(Resource.Id.BookPage);
            Button secondbutton = FindViewById<Button>(Resource.Id.LocationPage);
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Menu);
            // Create your application here
            button.Click += delegate
            {
                StartActivity(typeof(MainActivity));
            };

            secondbutton.Click += delegate
            {
                StartActivity(typeof(LocationActivity));
            };
        }
    }
}